# Rizzless Guitar Guide

Same functionality as 1.0.0-alpha, but with reduced nesting for easier reading and better for
maintaining. Specific topics can now be searched right off the bat without needing to go through
each sub menu everytime.
